<?php

namespace App\Repositories\Article;

interface ArticleRepository
{
    public function getAllArticles(): array;

}